# Abstract

The following document describes the process of creating a testing environment for the ansible scripts. Virtaulus development server will be used for this task.

# Introduction

On Virtalus development server, a new template has been specially crafted to simulate a server ready to be installed. This template will instantiate VMs with the bondings and virtual disks already configured. On-site team is responsible of installing and configuring servers up to the same state as this template does. The template uses OpenNebula's context features, bash scripting and some vibranium taken from Captain America's shield to set up the VMs.

# Set Up

If HyperCX template exists in the development cluster, skip this part.

To create the HyperCX template, download the Ubuntu 18.04 KVM image from the OS. Use the following settings:

|  Resource    | Amount  |
|--------------|---------|
|    CPU       |    2    |
|   vCPU       |    4    |
|    RAM       |    4 GB |
|   Network    |  Client |

Create 4 empty datablocks (20GB each) and attach them to the template. 

Set up PASSWORD on context section (hypercx) and make sure **SET_HOSTNAME** is also set.

Set up the following script as **Start Script**:

```
apt-get update
apt-get install -y bridge-utils
brctl addbr br0
ip=`ip a | grep 10.100. | awk '{print $2}'`
route=`ip r | grep default | awk '{print $3}'`
ip r del default
ip a del $ip dev eth0
brctl addif br0 eth0
ip a add $ip dev br0
ip l set br0 up
ip r add default via $route
```

Configure engineer keys for oneadmin account.

# Deployment

Template to be used is called **HyperCX**. Virtalus Bento smallest deployments will use at least three servers (3 VMs). MiniBento will use a single VM. RAM and CPU are pre-configured and should be enough for testing purposes...no need to be greedy.

<aside class="warning">
When instantiating the template, keep in mind these requirements:

* Do not set a unique name for the VM. When instantiating several VMs at once, if a name is specified, OpenNebula will use that name for all the VMs, and the template is configured to use the VM name as hostname. Hostnames **can not** be the same. If setting a VM name, use **%i** variable so OpenNebula will replace it with the VM's ID, creating unique names.

* Increase OS image size. By default, a 2G image is used. That size is not enough for the deployment. During instantiation, increase size for the OS disk. 30-40 GB are enough.
</aside>

<aside class="notice">
VMs after being created will take around 1 minute to be properly configured. This is approximately the time that takes the bash script to set up everything. After the bridge is set up, VM is ready.
</aside>

# Network

OpenNebula will automatically assign and manage IPs for the VMs (representing the compute nodes), so there will never be an IP conflict. For the LXD containers that will be deployed inside those VMs and will host the OpenNebula instances, IPs are manually assigned, and there is a risk for duplicated IPs. For this reason, each engineer has an IP pool defined next, it is his responsability to use this IPs as he likes, and he can not use IPs outside his address pool. This is configured inside *inventory_generated_testing* or *inventory_mini_bento_generated_testing*. In the case of the node, you must use the IP assigned by HyperCX (for example, if HyperCX assigned the IP 10.10.0.28, you must set "28" in the IP option of the inventory file, since 10.10.0.0/16 + 28 = 10.10.0.28). For the other containers (orchestrators, zabbix_proxy, etc) you must use a number (any number) from the range that you have assigned below (do not repeat it or you will have an IP conflict): 

* Franco - 501-600

* Nacho - 100-300

* Ibrahim - 651-700

* Kamran - 751-800
    
* Junior - 801-850

Now, you are ready to use Ansible scripts. Follow [this guide](./Readme.md).

# Configurations

On **group_vars/all** some settings must be changed for testing deployments:

* this_is_a_poc: Set to false

* remote_monitor: Set to false

* client_name: Use your name

* project: whatever you want to idenify your cluster

* vpn_users: remove everyoe except you. Others should not get notification emails when you deploy a new cluster


