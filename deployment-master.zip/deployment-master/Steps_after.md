# Required configurations after running the scripts

After running the scripts, nodes will be fully configured, just OpenNebula's configurations are missing.

## Sunstone modifications

asd

## Add hosts

Add all the hosts by it's hostname. Hostnames are defined on /etc/hosts on each node. Ansible will use the existing hostname on each node.

## Configure datastore

asdasd

## Create Virtual Networks

### Client VNet

Mode: 802.1Q
Bridge name: br2130
Physical device: bond0
Address: Defined on platform document

## Public VNet

Mode: 802.1Q
Bridge Name:
Physical device: bond0
Address: Defined by provider


