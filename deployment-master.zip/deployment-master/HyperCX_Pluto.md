# Bootstrap

On a RPI3, follow the following steps:

* Install a fresh Raspbian

* Enable ssh server (systemctl enable ssh)

* Connect using pi:raspberry credentials  

* Expand filesystem

* Copy public key to root user

* Install python

* Update **inventory_pluto** with RPI's IP (no need to configure any var)

* Test:

```
ansible -i inventory_pluto pluto -u root -m ping
```

* Install

```
ansible-playbook -i inventory_pluto build_hypercx_pluto.yml
```

# Installation

Download Pluto image from Mega drive and dump it into the microsd card. This link shows how to do it:

https://www.raspberrypi.org/documentation/installation/installing-images/

# Usage

On the deployment switch, configure a trunk port with at least the management network and the public network. Connect HyperCX_Pluto to that port and to a power supply. After HyperCX_Pluto initializes, a WiFi should appear called **HyperCX_Pluto**. Password is **hypercx123**. On-site engineer will connect to this network and an IP will be given via dhcp on the range 192.168.150.100-192.168.150.150. IP on HyperCX_Pluto is 192.168.150.1. Connect via ssh with user: **hypercx** and password
**hypercx@123**.

Configure the wired network inside HyperCX_Pluto. An example file is to be located on */etc/network/interfaces_example*. Copy this template inside */etc/network/interfaces.d*:

```
cp /etc/network/interfaces_example /etc/network/interfaces.d/wired
```

Edit */etc/network/interfaces.d/wired* and update vlans and ips. Restart networking service:

```
systemctl restart networking
```

Check that everything was properly configured and that there is internet access. A dns query should be enough:

```
nslookup google.com 8.8.8.8
```

Start the zerotier service:

```
zerotier-cli join 12ac4a1e711fc681
```

The output should look like:
**200 join OK**

if the output is:
**0 join**

most likely the MASQUERADE rule is affecting zerotier. You will need to remove it, reconnect zerotier and then set it up again

```
iptables -D POSTROUTING -t nat -j MASQUERADE -m comment --comment "Ansible Masquerade"
zerotier-cli join 12ac4a1e711fc681
iptables -A POSTROUTING -t nat -j MASQUERADE -m comment --comment "Ansible Masquerade"
```


An ip on the network 192.168.196.0/24 will be assigned.
