# Introduction

This repository contains a set of ansible roles designed to automate the installation process of Virtalus HyperCX nodes. This task will be done with a single command that will take care of the entire process.

These are the operations that will be performed:

* Install and configure three LXD containers on the first three nodes.

* Install and configure a database server inside each container for hosting OpenNebula's database.

* Install OpenNebula on each of the previously created containers.

* Configure each node as an OpenNebula node.

* Install and configure gluster on each compute node.

Each task have been designed with idempotency in mind. This means than the result of performing it once is exactly the same as the result of performing it repeatedly without any intervening actions. In other words, if anything fails you can safely run these tasks again as many times needed, the result at the end will be the same.

This roles will run inside any computer (could be any laptop), this will be the client, and will connect to every Virtalus HypecCX server (those will be the servers).

# Requirements

## For the servers

Each server must have an Operating System installed. This servers will have the following requisites:

* Ubuntu 18.04

* No RAID configured. Each disk must be independently accessed.

* The managemenet bridge must be configured.

* Internet connectivity (through the management bridge).

* Python installed (python 2.7 or python3). In this case, we will use ubuntu's python package that installs python 2.7.

* Public keys configured for passwordless ssh access for root user.

* Hostname must be different across the servers.

## For the client

The client must not be any of the servers. Any other computer can be used. These are the requirements:

* Ansible (latest possible version)

* Passwordless ssh access to the server's root account

* MySQL python module. Package is called **python-pymysql** on Ubuntu.

* Netaddr python module. Package is called **python-netaddr**

* Packages to generate pdf client report: pandoc, texlive-latex-base, texlive-fonts-recommended, texlive-latex-extra

* Zabbix api (pip install zabbix-api)

# Configuration

For every deployment, a few adjustments might be needed. There are two main files that you will need to set up:

### Inventory file
Contains the ip address and network configurations of every node that will be set up. Two template files already exist: *inventory_generated* for bento deployments and *inventory_mini_bento_generated* for mini bento deployments. There is a version of each of these files ending in **testing**, those are meant to be used with virtual environments deployed on dev cluster. Each node is configured in an array of hashes. This is the only thing that will need to be configured. The configuration options available for each node are as follows:

* name: Name of your favorite constellation. Do not change existing values on the inventory file.
* ip: IP of the node. This value will be added to the network defined on *management_network*. For example, if a value of 349 is set, 349 IPs will be added to the network 10.10.0.0/16.
* parent: Do not modify
* parent2: People always have two parents. Do not modify
* grandpa: Your parents had parents..right? Do not modify
* ipv6: If the datacenter supports ipv6, they should be configured. They are only meant to be configured on the routers
* to_cluster: Feature in development. Eventually will allow to create complex deployments and fog architectures.

### group_vars/all
Contains some configurations that will need adjustments. Most configurations are explained in the file, and the ones that require further explanation are described next:

###### Passswords

Passwords are encrypted using ansible vault. Most passwords can remain in that way, and others MUST remain like they are on the file. The only password that should be changed is **opennebula_password**. To generate a new encrypted password use the following command:

```
ansible-vault encrypt_string --ask-vault-pass 'PASSWORD' --name 'opennebula_password'
```

###### Gluster_disks

Disks that will be used for GlusterFS. On dev cluster, using HyperCX template, those are vdb, vdc, vdd, vde.

###### This_is_a_poc

If the deployment is a PoC, we always create some resources for the user (download some teplates and create a couple of vms).


# Usage

If these scripts will be used on Virtalus's testing platform, check [this guide](./Testing_platform.md) first.

Clone this repo, enter the folder and run the playbook:

```
git clone https://gitlab.com/virtalus/deployment
cd deployment
```

Next, check connectivity is OK, and nodes are correctly set up:

For Bento:

```
ansible -i inventory_generated compute-nodes -u root -m ping
```

For mini_Bento:

```
ansible -i inventory_mini_bento_generated compute-nodes -u root -m ping
```

Any ansible action will require a password. 

Your output should look like this:

```
172.20.12.5 | SUCCESS => {
    "changed": false,
    "ping": "pong"
}
172.20.12.7 | SUCCESS => {
    "changed": false,
    "ping": "pong"
}
172.20.12.6 | SUCCESS => {
    "changed": false,
    "ping": "pong"
}
```

If virtual routers are to be used, run the following playbook:

```
ansible-playbook -i inventory_mini_bento_generated playbook/bootstrap_network.yml
```

Next, run the scripts:

For Bento:

```
ansible-playbook -i inventory_generated playbook/infra_setup.yml
```

For miniBento:

```
ansible-playbook -i inventory_mini_bento_generated playbook/build_mini_bento.yml
```

# Growing a cluster

Growing a cluster works with the **upgrade_minibento** playbook, just like a normal upgrade, but a few operations must be done first:

## New servers

On every new server that will be added to the cluster, the server requirements for a new cluster must be met. Check [previous requirements](#for-the-servers).

Besides those requirements:

### Upgrade

Manually run apt upgrade since ansible will not do it

### Create hypercx user

Because the upgrade_minibento playbook is used, **hypercx** user is used instead of **root** user. This user must be manually added.

```
adduser hypercx
```

Set hypercx as password since the playbook will change it anyway. Besides you need to add your key to the user's authorized keys. As **hypercx** user run this:

```
ssh-keygen
echo "$public_key" > /home/hypercx/.ssh/authorized_keys
```

Finally, allow **hypercx** user to run sudo withour passwords. Add the following snippet to */etc/sudoers*:

```
hypercx ALL=(ALL) NOPASSWD: ALL
```

### Post operations

After the cluster has been grown with new servers, if the cluster supports LXD and KVM, the new host intsance resources must be cut by half manually.

# Notes

## Encrypting password

```
ansible-vault encrypt_string --ask-vault-pass 'secure_text' --name 'var_name'
```

# Tested environments

These roles have been tested with the following releases:

* Ubuntu 18.04

* OpenNebula 5.6.1 and newer

* Gluster 5 and newer


# Operations performed

|           Role                      |   Operation                            | B | MB | Upgrade |  Requires   |
|-------------------------------------|----------------------------------------|---|----|---------|-------------|
| Install LXD and Bootstrap Container | Install LXD                            | Y | Y  |    N    |             |
|                                     | Add Conntrack modules                  | Y | Y  |    N    |             |
|                                     | Configure LXD                          | Y | Y  |    N    |             |
|                                     | Launch LXD Container                   | Y | Y  |    N    |             |
|                                     | Configure new container                | Y | Y  |    N    |             |
|                                     | Configure new container                | Y | Y  |    N    |             |
| Pre-installation Checks on All      | Restore apt sources                    | Y | Y  |    Y    |             |
| Configure NTP on Compute Nodes      | Install and run ntp service            | Y | Y  |    Y    |             |
| Install MySQL on frontends          | Install MariaDB                        | Y | Y  |    N    |             |
|                                     | Configure MariaDB                      | Y | Y  |    N    |             |
|                                     | Create OpenNebula DB and user          | Y | Y  |    N    | database_user, database_password |            |
|                                     | Create Zabbix user                     | Y | Y  |    N    |             |
| Install OpenNebula on frontends     | Disable cloud init                     | Y | Y  |    Y    |             |
|                                     | Add OpenNebula repos                   | Y | Y  |    Y    | one_repos_pgp_key, one_repos_url |
|                                     | Stop OpenNebula Services               | N | N  |    Y    |             |
|                                     | Backup configurations and DB           | N | N  |    Y    |             |
|                                     | Install OpenNebula                     | Y | Y  |    Y    |             |
|                                     | Configure oneadmin password            | Y | Y  |    Y    | opennebula_password |
|                                     | Configure RAFT HOOK                    | N | N  |    Y    | opennebula_virtual_ip |
|                                     | Upgrade OpenNebula                     | N | N  |    Y    |             |
|                                     | Configure one Host Hook                | N | N  |    Y    | Deprecated on HCX 10.5.1 | 
|                                     | Start OpenNebula                       | Y | Y  |    Y    |             |
|                                     | Configure logs replication             | Y | Y  |    Y    |             |
| Fetch ssh keys from orchestrator1   | Configure oneadmin's ssh               | Y | Y  |    Y    |             | 
|                                     | Generate ssh keys for root             | Y | Y  |    Y    |             |
|                                     | Get oneadmin and root ssh keys         | Y | Y  |    Y    |             |
| Configure OpenNebula nodes          | Add OpenNebula repos                   | Y | Y  |    Y    | one_repos_pgp_key, one_repos_url |
|                                     | Install OpenNebula Node                | Y | Y  |    Y    |             |
|                                     | Restart libvirt services               | Y | Y  |    Y    |             |
| Push ssh keys to compute nodes      | Send oneadmin and root keys to nodes   | Y | Y  |    Y    |             |
|                                     | Fix key permits                        | Y | Y  |    Y    |             |
| Basic OS configs on ALL nodes       | Upgrade system                         | Y | Y  |    Y    |             |
|                                     | Create banner                          | Y | Y  |    Y    |             |
|                                     | Install sudo and important apps        | Y | Y  |    Y    |             |
|                                     | Remove Ubuntu User                     | Y | Y  |    Y    |             |
|                                     | Create hypercx user                    | Y | Y  |    Y    | hypercx_user, hypercx_password |
|                                     | Configure root user (password and ssh) | Y | Y  |    Y    | root_password |
|                                     | Authorize virtalus engineers keys      | Y | Y  |    Y    |             |
|                                     | Generate /etc/hosts file               | Y | Y  |    Y    |             |
|                                     | Remove hypercx repos                   | Y | Y  |    Y    | opennebula_repos_url            |
|                                     | Configure timezone                     | Y | Y  |    Y    |             |
| Install Zabbix Agent on ALL         | Install zabbix repo                    | Y | Y  |    Y    | zabbix_deb_repo |
|                                     | Install zabbix agent                   | Y | Y  |    Y    |             |
|                                     | Configure zabbix agent                 | Y | Y  |    Y    |             |
|                                     | Config zabbix DB monitoring            | Y | Y  |    Y    |             |
|                                     | Config zabbix to monitor user keys     | Y | Y  |    Y    | hypercx_user |
|                                     | Config zabbix to monitor mount points  | Y | Y  |    Y    |             |
|                                     | Config zabix to monitor services       | Y | Y  |    Y    |             |
|                                     | Config zabix to monitor ovpn           | Y | Y  |    Y    |             |
| Install GlusterFS on storage nodes  | Install gluster and dependencies       | Y | Y  |    N    | gluster_ppa |
|                                     | Validate no disk is used by OS         | Y | Y  |    N    |             |
|                                     | Destroy gluster volumes if they exist  | Y | Y  |    N    |             |
|                                     | Umount bricks if they are mounted      | Y | Y  |    N    | gluster_disks |
|                                     | Build GPT and format bricks            | Y | Y  |    N    | gluster_disks |
|                                     | Mount bricks and create gluster dirs   | Y | Y  |    N    | gluster_disks |
|                                     | Install and configure glusix           | Y | Y  |    N    |             |
| Push SSH keys to storage nodes      | Same as before, but to storage nodes   | Y | Y  |    Y    |             |
| Create Gluster Volume on Storage 1  | Add gluster peers                      | Y | Y  |    N    |             |
|                                     | Create and tune gluster volume         | Y | Y  |    N    |             |
| Add Gluster Mount                   | Install gluster client                 | Y | Y  |    Y    | glusterfs_ppa |
|                                     | Create dirs and links for mounts       | Y | Y  |    Y    |             |
|                                     | Mount using NFS and GlusterFS client   | Y | Y  |    N    |             |
|                                     | Configure automount script             | Y | Y  |    N    |             |
| Install Zabbix Proxy                | Install zabbix proxy and dependencies  | Y | Y  |    Y    | zabbix_deb_repo |
|                                     | Install and configure MariaDB          | Y | Y  |    Y    | database_root_password |
|                                     | Bootstrap database                     | Y | Y  |    Y    |             |
|                                     | Generate TLS identity                  | Y | Y  |    Y    |             |
|                                     | Configure Zabbix Proxy                 | Y | Y  |    Y    |             |
| Install Zabbix Server               | Install zabbix server and dependencies | Y | N  |    Y    | zabbix_deb_repo |
|                                     | Install and configure MariaDB          | Y | N  |    Y    | database_root_password |
|                                     | Bootstrap database                     | Y | N  |    N    |             |
|                                     | Configure Zabbix Server                | Y | N  |    Y    |             |
| Configure zabbix resources          | Upload templates                       | Y | N  |    Y    | zabbix_admin_password |
|                                     | Add cluster components                 | Y | N  |    Y    | zabbix_admin_password, client_name, project | 
|                                     | Configure email alerts                 | Y | N  |    Y    |             |
|                                     | Create Zabbix maps                     | Y | N  |    Y    |             |
| Push SSH keys to frontends          | Same as before, but to frontends       | Y | Y  |    Y    |             |
| Clear OpenNebula configurations     | Stop OpenNebula Services               | Y | Y  |    N    |             |
|                                     | Destroy OpenNebula DB                  | Y | Y  |    N    |             |
|                                     | Remove opennebula keys and configs     | Y | Y  |    N    |             |
|                                     | Start OpenNebula                       | Y | Y  |    N    |             |
| Set up OpenNebula HA                | Add frontends to the zone              | Y | N  |    N    |             |
|                                     | Configure one Host Hook                | Y | N  |    N    |             | 
|                                     | Configure Hooks and Server ID          | Y | N  |    N    | opennebula_virtual_ip |
|                                     | Replicate DB and keys                  | Y | N  |    N    |             |
| Configure OpenNebula resources      | Create KVM and LXD clusters            | Y | Y  |    N    | add_lxd_support |
|                                     | Rename system datastore                | Y | Y  |    N    |             |
|                                     | Create hosts                           | Y | Y  |    N    |             |
|                                     | Populate clusters                      | Y | Y  |    N    |             |
|                                     | Change datastores driver to shared     | Y | Y  |    N    |             |
|                                     | Configure marketplaces                 | Y | Y  |    N    |             |
|                                     | Rename default zone                    | Y | Y  |    N    |             |
|                                     | Create client VNET                     | Y | Y  |    N    |             |
|                                     | Configure PoC resources                | Y | Y  |    N    | this_is_a_poc |
| Set up OpenNebula monitoring        | Install zabbix-sender                  | Y | Y  |    Y    |             |
|                                     | Copy monitoring scripts and confs      | Y | Y  |    Y    |             |
|                                     | Add crontab entries                    | Y | Y  |    Y    |             |
| Create reverse proxy on fronteds    | Install certbot                        | Y |    |    Y    |             |
|                                     | Configure routers if managed           | Y | Y  |    Y    |             |
|                                     | Install and configure Nginx            | Y | Y  |    Y    |             |
|                                     | Generate and configure certificate     | Y | Y  |    Y    | domain_name |
| Generate report                     | Generate cluster report and email it   | Y | Y  |    Y    |             |
|                                     | Add cluster to central Zabbix          | Y | Y  |    Y    | remote_monitor |










