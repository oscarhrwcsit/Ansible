# Introduction

On hypercx, new code goes into a branch called **hypercx_master**. This branch follows opennebula's stable progress, while **master** branch follows opennebula's unstable progress.

This file shows how to bump HyperCX version.

# Generate packages

Add opennebula (upstream) repo if you haven't:

```
git remote add opennebula https://github.com/OpenNebula/packages
```

Update upstream

```
git fetch opennebula
```

Make sure you are in hypercx_master branch

```
git checkout hypercx_master
```

Merge new code from OpenNebula

```
git merge tags/release-5.12.8
```

(5.12.8 is OpenNebula's latest version)

Create a branch from **hypercx_master** with the version number coded in the name.
Standing on **hypercx_master** run:

```
git checkout -b hypercx_10.6.2
```

This command creates a new branch (hypercx_10.6.2) as a clone of *hypercx_master*. But, if hypercx_10.6.2 already existed and you only want to update new code that you have in *hypercx_master* branch, you need to change to the existing branch (hypercx_10.6.2) and merge the code there:

```
git checkout hypercx_10.6.2
git merge hypercx_master
```

(10.6.2 is HyperCX new release)


This procedure is only meant for packages repo. In the early days we had our own fork of opennebula, so we had to do something similar with that repo, but that ended when they released the Enterprise Edition.


# Usage

First, modify *inventory_packages* file with the IP of the VM that will handle the task.

Check if the VM is reachable and it's ready for Ansible:

```
ansible -i inventory_packages generator -u root -m ping
```

Launch the playbook:

```
ansible-playbook -i inventory_packages playbook/packages_generator.yml -e "version=10.6.0 distro=20.04 one_version=5.12.4 release_code=ubuntu1"
```

Possible releases codes are:

    alma<compilation_iteration>
    ubuntu<compilation_iteration>
    redhat<compilation_iteration>

The release code can't contain "-" and others especials characters, can only contain letters and numbers.

Packages will be found inside the VM under: */root/repo_one-{{ version }}*

This is the config that should be set on sources.list:
```
deb [trusted=yes] file:///home/sergio/repo_one-5.8.2 dists/
```

For the RedHat's based systems the .repo file will be:

```
[HyperCX]
name=Virtalus HyperCX Repo
baseurl=http://127.0.0.1:8000/packages
enabled=1
gpgcheck=1
gpgkey=https://packages.virtalus.com/hypercx-appliances/pubkey.asc
```
The baseurl paraeter needs to point to the folder that contains the repodata folder. Parameters as $basearch and $release can be used to build this URL and make more simple the construction for more than one release os the OS.


