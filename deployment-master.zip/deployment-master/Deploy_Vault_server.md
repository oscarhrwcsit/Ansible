# Overview

Vault is....you know what it is.

# Storage server

This section is used to deploy a new Vault server. If a Vault server already exists on the DC, you can skip it and continue to **Usage**.

Vault uses a server to store the backups. This server internally uses the same network architecture as our miniBentos. Three bridges are created inside each Vault server:

* br0: Management bridge. Provides connectivity to containers running inside the node, and the node itself.

* br1: Public bridge. This bridge has two roles: provide internet access to the node's services (like zabbix) and to connect to the backup network. This bridge (unlike on the miniBentos) will be configured with an IP address from the backup network (.2). 

* br100: Client bridge. This bridge is only set for compatibility reasons. Use any vlan here, it will not be used.

## Deployment

There are two different deployment types. Each type has it's own inventory file.

### Common

Whatever the server type, some important aspects to have in mind:

- Define disks using same gluster_disks variable in groupvar
- Atleast 4 disks required(OS disk not included)

### Vault_isolated

This mode is designed to have a fully isolated vault server (not part of any cluster) that will provide services to several clusters. This mode will install a virtual router, get it's own VPN and get configured in central Zabbix as an independent cluster.

In order to use ansible to deploy a new storage server, first configure **inventory_vault_isolated_generated**. Also, the following vars from **group_vars/all** must be set:

* management_bridge
* dns
* auth_key_path
* zabbix_deb_repo
* zabbix_rpm_repo
* database_root_password
* gluster_disks
* hypercx_user
* public_ip
* hypercx_password
* root_password
* zabbix_timezone
* remote_monitor
* zabbix_url
* client_name
* project

Run ansible:

```
ansible-playbook -i inventory_vault_isolated_generated playbook/bootstrap_network.yml
ansible-playbook -i inventory_vault_isolated_generated playbook/build_vault.yml
```

* In inventory file there is a variable called **cluster_type** set to: **vault_shared**.

* If HyperCX Vault fails or crashes it won't restart itself*. Log files are stored in `/var/log/one/hypercx-vault.log` crash logs will be there in case of error.

### Vault_shared

This mode is intended for a vault server that will be used by a single cluster. When using this mode, this vault will use connectivity from the cluster. It will also be added to the clsuter's zabbix server (if any) and will be part of this cluster's group in central zabbix server (will reach central zabbix through the cluster's zabbix proxy).

* In inventory file there is a variable called **cluster_type** set to: **vault_shared**.
* Client name and cluster name must match the original cluster. This will allow that *generate_report* role adds this server using the cluster's existing zabbix proxy instance.
* On inventory file, add or remove zabbix server depending if cluster is Bento or miniBento.
* Zabbix admin password in group_vars must be the one configured in the cluster's zabbix (only for Bento).

```
ansible-playbook -i inventory_vault_shared_generated playbook/build_vault.yml
```

## Testing Deployment

Only available on v10.6.2-fixed branch.

```
ansible-playbook -i inventory_vault_shared_generated playbook/build_vault_testing.yml
```



