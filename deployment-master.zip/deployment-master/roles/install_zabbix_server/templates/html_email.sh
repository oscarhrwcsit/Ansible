#!/bin/sh
export smtpemailfrom=service@virtalus.com
export zabbixemailto="$1"
export zabbixsubject="$2"
export zabbixbody="$3"
export smtpserver=smtp.office365.com
export smtplogin={{ email_account }}
export smtppass={{ email_account_password | replace(' ','') }}
/usr/bin/sendEmail -f $smtpemailfrom -t $zabbixemailto -u $zabbixsubject -m $zabbixbody -s $smtpserver:587 -o tls=yes -xu $smtplogin -xp $smtppass -o message-content-type=html
