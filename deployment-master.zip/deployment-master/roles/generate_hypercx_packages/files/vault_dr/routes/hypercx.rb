
require 'SunstoneHypercxBackup'

get '/hypercx/vault-info' do
    [200, HypercxVault.new.getAllInfo.to_json]
end

get '/hypercx/vault-backup' do
    [200, HypercxVault.new.getAllApps.to_json]
end

get '/hypercx/dr-info' do
    [200, HypercxDr.new.getAllInfo.to_json]
end

get '/hypercx/dr-backup' do
    [200, HypercxDr.new.getAllApps.to_json]
end
