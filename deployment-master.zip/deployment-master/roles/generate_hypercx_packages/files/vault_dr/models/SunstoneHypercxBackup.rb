ONE_LOCATION = ENV['ONE_LOCATION']

if !ONE_LOCATION
  RUBY_LIB_LOCATION = '/usr/lib/one/ruby' if !defined?(RUBY_LIB_LOCATION)
  GEMS_LOCATION     = '/usr/share/one/gems' if !defined?(GEMS_LOCATION)
else
  RUBY_LIB_LOCATION = ONE_LOCATION + '/lib/ruby' if !defined?(RUBY_LIB_LOCATION)
  GEMS_LOCATION     = ONE_LOCATION + '/share/gems' if !defined?(GEMS_LOCATION)
end

if File.directory?(GEMS_LOCATION)
  Gem.use_paths(GEMS_LOCATION)
end

$LOAD_PATH << RUBY_LIB_LOCATION
require 'opennebula'

MODE_DR = 1001
MODE_VAULT = 1002

DB_BACKUP_IN_PROGRESS = 3041
DB_BACKUP_UNSUCCESSFUL = 4041
DB_BACKUP_SUCCESSFUL = 101

include OpenNebula

CONFIG_FILE_PATH_DR = "/etc/hypercx-backups/dr.conf.yaml"
CONFIG_FILE_PATH_VAULT = "/etc/hypercx-backups/vault.conf.yaml"

def init_remote_db
  if(@CONFIG["SunstoneEnabled"])
    remote_db_dat_isset = false
    out = `ssh -t  #{@CONFIG["remote"]["username"]}@#{@CONFIG["remote"]["ip"]} 'cd ~/#{@CONFIG["remote"]["username"]}/#{@CONFIG["remote"]["UUID"]} && ls *.yaml'`
    if $?.exitstatus != 0
      $remote_db_dat = Hash.new
    else
      out  = out.gsub!("\r","") if out.include?("\r")
      out = out.split("\n")
      out.each do |file|
        if(file == "info.yaml")
          out = `ssh -t  #{@CONFIG["remote"]["username"]}@#{@CONFIG["remote"]["ip"]} 'cd ~/#{@CONFIG["remote"]["username"]}/#{@CONFIG["remote"]["UUID"]} && cat info.yaml'`
          $remote_db_dat =  YAML::load(out)
          remote_db_dat_isset = true
        end
      end
    end
  end
  $remote_db_dat = Hash.new unless defined?($remote_db_dat) || !remote_db_dat_isset
  return true
end

class HypercxBackup
  def initialize
    @errorStatus = false
    @client = Client.new
    @CONFIG = Hash.new
    @errorStatus = true unless configsExist?
    @apps = Array.new
  end

  def configsExist?
    File.exist?(CONFIG_FILE_PATH_DR) && File.exist?(CONFIG_FILE_PATH_VAULT)
  end

  def getCurrBackups
    _currbackup = ""
    _inprogress = false

    if @CONFIG["SunstoneEnabled"]
      $remote_db_dat.each do |idDisk, backupDat|
        if backupDat['HISTORY'].to_i == DB_BACKUP_IN_PROGRESS
          _currbackup = self.get_vm_name idDisk.split("_")[0][1..-1]
          _inprogress = true
          break
        end
      end
    end

    _dat = Array.new
    _dat.push(Hash[
                  "NAME" => "In Progress?",
                  "DESC" => "Yes"
              ]) if _inprogress
    _dat.push(Hash[
                  "NAME" => "In Progress?",
                  "DESC" => "No"
              ]) if !_inprogress
    _dat.push(Hash[
                  "NAME" => "Backup in progress of",
                  "DESC" => _currbackup
              ]) unless _currbackup == ""

    return _dat
  end

  def get_backup_schedule
    _schedule_arr = Array.new
    @CONFIG['day_of_week'].each do |week|
      _day = ""
      case week
      when 0
        _day = "Sunday"
      when 1
        _day = "Monday"
      when 2
        _day = "Tueday"
      when 3
        _day = "Wednesday"
      when 4
        _day = "Thursday"
      when 5
        _day = "Friday"
      when 6
        _day = "Saturday"
      else
        _day = "(ERROR)"
      end
      @CONFIG['time'].each do |time|
        _schedule_arr.push(Hash[
                               "DAY" => _day,
                               "TIME" => time
                           ])
      end
    end
    return _schedule_arr
  end

  def getAllInfo
    return Hash[] if @errorStatus || !@CONFIG["SunstoneEnabled"]

    return Hash[
        "info" => Array[
            Hash[
                "NAME" => "Backup TAG Name" ,
                "DESC" => @CONFIG["backups_tag_name"]
            ],
            Hash[
                "NAME" => "Notify Zabbix Server" ,
                "DESC" => @CONFIG["notify_zabbix_server"]
            ],
            Hash[
                "NAME" => "Notify Zabbix Proxy" ,
                "DESC" => @CONFIG["notify_zabbix_proxy"]
            ],
            Hash[
                "NAME" => "Number of incremental backups before Full backup" ,
                "DESC" => @CONFIG["backup_incremental_limit"]
            ]
        ],
        "BACKUPS_IN_PROGRESS" => self.getCurrBackups,
        "BACKUPS_SCHEDULE" => get_backup_schedule
    ]
  end

  def get_vm_name(vmID)
    vm = VirtualMachine.new_with_id(vmID.to_i,@client)
    rc = vm.info
    if OpenNebula.is_error?(rc)
      return "ERROR!"
    else
      return vm.to_hash["VM"]["NAME"]
    end
  end

  def backups_sort()
    return @apps if @apps.size <= 1
    swap = true
    while swap
      swap = false
      (@apps.length - 1).times do |x|
        if @apps[x]['DATE'].to_i < @apps[x+1]['DATE'].to_i
          @apps[x], @apps[x+1] = @apps[x+1], @apps[x]
          swap = true
        end
      end
    end
    @apps
  end
end

class HypercxVault < HypercxBackup
  def initialize
    super
    unless configsExist?
      @errorStatus = true
      return
    end
    @CONFIG = YAML::load_file(CONFIG_FILE_PATH_VAULT)
    init_remote_db
  end

  def checkService
    rc = system("systemctl is-active --quiet hypercx-vault")
    if (rc)
      return true
    end
    return false
  end

  def getAllApps
    @apps = Array.new
    self.refresh
    self.backups_sort
    return @apps
  end

  def getAllInfo
    allInfo = super
    return allInfo if @errorStatus || !@CONFIG["SunstoneEnabled"]
    allInfo["info"].push(
        Hash[
            "NAME" => "Backup Rotation Period(Days)" ,
            "DESC" => @CONFIG["rotation_period"]
        ]
    )
    allInfo["info"].push(
        Hash[
            "NAME" => "Service running?" ,
            "DESC" => checkService
        ]
    )
    return allInfo
  end

  def refresh
    return if @errorStatus || !@CONFIG["SunstoneEnabled"]

    $remote_db_dat.each do |idDisk, backupDat|
      if backupDat['HISTORY'].to_i == DB_BACKUP_UNSUCCESSFUL
        @apps.push(Hash["NAME" => self.get_vm_name(idDisk.split("_")[0][1..-1]) , "STATUS" => 'FAILED', 'DISK' => idDisk.split("_")[1][1..-1],'DATE' => "1604935675", "VMID" => idDisk.split("_")[0][1..-1], 'MPID'=> -1, 'INCREMENTALS' => @CONFIG['backup_incremental_limit'].to_i-backupDat['inc_count'].to_i])
        puts backupDat['inc_count']
        puts "\n"
        puts @CONFIG['backup_incremental_limit']
      end
    end

    @client = Client.new
    mpapppool = MarketPlaceAppPool.new(@client, -1)
    rc = mpapppool.info
    unless OpenNebula.is_error?(rc) || @errorStatus
      mp_id = @CONFIG['remote']['marketplace_id']
      mpapppool.each do |mpapp|
        if mpapp.to_hash && mpapp.to_hash['MARKETPLACEAPP']['MARKETPLACE_ID'].to_i == mp_id
          @apps.push(Hash["NAME" => self.get_vm_name(mpapp.to_hash['MARKETPLACEAPP']["TEMPLATE"]['IMPORT_ID'].split("_")[0]) , 'STATUS' => 'SUCCESS', 'DISK' => mpapp.to_hash['MARKETPLACEAPP']["TEMPLATE"]['IMPORT_ID'].split("_")[1], 'MPID'=>  mpapp.to_hash['MARKETPLACEAPP']["ID"],'DATE' => mpapp.to_hash['MARKETPLACEAPP']["REGTIME"],"VMID" => mpapp.to_hash['MARKETPLACEAPP']["TEMPLATE"]['IMPORT_ID'].split("_")[0] , 'INCREMENTALS' => @CONFIG['backup_incremental_limit'].to_i-$remote_db_dat["v#{mpapp.to_hash['MARKETPLACEAPP']["TEMPLATE"]['IMPORT_ID'].split("_")[0]}_d#{mpapp.to_hash['MARKETPLACEAPP']["TEMPLATE"]['IMPORT_ID'].split("_")[1]}"]['inc_count'].to_i])
        end
      end
    end
  end
end

class HypercxDr < HypercxBackup
  def initialize
    super
    unless configsExist?
      @errorStatus = true
      return
    end
    @CONFIG = YAML::load_file(CONFIG_FILE_PATH_DR)
    init_remote_db
  end

  def checkService
    rc = system("systemctl is-active --quiet hypercx-dr")
    if (rc)
      return true
    end
    return false
  end

  def getAllInfo
    allInfo = super
    puts if @errorStatus || !@CONFIG["SunstoneEnabled"]
    return allInfo if @errorStatus || !@CONFIG["SunstoneEnabled"]
    allInfo["info"].push(
        Hash[
            "NAME" => "Is this a Backup Cluster?" ,
            "DESC" => @CONFIG["IsBackupCluster"]
        ]
    )
    allInfo["info"].push(
        Hash[
            "NAME" => "Service running?" ,
            "DESC" => checkService
        ]
    )
    return allInfo
  end

  def getAllApps
    return @apps if @errorStatus || !@CONFIG["SunstoneEnabled"]

    $remote_db_dat.each do |idDisk, backupDat|
      status = ""
      case backupDat["HISTORY"]
      when DB_BACKUP_SUCCESSFUL
        status = "SUCCESSFUL"
      when DB_BACKUP_UNSUCCESSFUL
        status = "UNSUCCESSFUL"
      when DB_BACKUP_IN_PROGRESS
        status = "IN-PROGRESS"
      end
      puts @CONFIG['backup_incremental_limit'].to_i
      puts "\n"
      puts backupDat['inc_count']
      puts "\n"
      @apps.push(Hash["NAME" => self.get_vm_name(idDisk.split("_")[0][1..-1]) , "STATUS" => status, 'DISK' => idDisk.split("_")[1][1..-1], 'DATE' => backupDat["TIMESTAMP"], "VMID" => idDisk.split("_")[0][1..-1], 'INCREMENTALS' => @CONFIG['backup_incremental_limit'].to_i-backupDat['inc_count'].to_i])
    end

    return @apps
  end
end
