define(function(require) {

    TAB_ID = require('./dr-backup-tab/tabId');
    var Buttons = require('./dr-backup-tab/button');
    var Actions = require('./dr-backup-tab/action');
    var Table = require('./dr-backup-tab/datatable');
    var DATATABLE_ID = "dr-backup";

    var _dialogs = [
    ];

    var _panels = [
    ];

    var Tab = {
        tabId: TAB_ID,
        title: "Replicas",
        icon: 'fa-clone',
        tabClass: "subTab",
        parentTab: "dr-top-tab",
        listHeader: "Status",
        lockable: false,
        subheader: '<span>\
            <span class="total_dr"/> <small>Total</small>\
        </span>',
        resource: 'dr-backup',
        buttons: Buttons,
        actions: Actions,
        dataTable: new Table(DATATABLE_ID, {actions: true, info: false}),
        panels: _panels,
        dialogs: _dialogs
    };

    return Tab;
});
