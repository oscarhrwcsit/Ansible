
define(function(require) {

    TAB_ID = require('./dr-info-tab/tabId');
    OPENNEBULA = require('opennebula')
    var HtmlTemplate = require('hbs!./dr-info-tab/html');
    var HtmlFailureTemplate = require('hbs!./dr-info-tab/htmlFailure');
    var _table_dat;
    
    $.ajax('/hypercx/dr-info',
    {            
        async: false,
        success: function (data, status, xhr) {
            _table_dat = data;
        }
    });
    _status = false;
    if(_table_dat["info"]){
        var _status_ind = _table_dat["info"].map(function (table) { return table.NAME; }).indexOf("Service running?")
        if(_status_ind != -1 && _table_dat["info"][_status_ind]["DESC"]){
            _status = true;
            _table_dat["info"].splice(_status_ind,1);
        }
        else{
            _status = false;
        }
    }
    if(_table_dat["info"] && !_table_dat["info"][_table_dat["info"].map(function (table) { return table.NAME; }).indexOf("ErrorState")]){
        var Tab = {
        tabId: TAB_ID,
        title: "Info",
        icon: 'fa-info-circle',
        tabClass: "subTab",
        parentTab: "dr-top-tab",
        listHeader: "DR Status",
        lockable: false,
        content: HtmlTemplate({
            table_dat: _table_dat["info"],
            isEnabled_DR: _status,
            table_dat_progress: _table_dat["BACKUPS_IN_PROGRESS"],
            table_dat_schedule: _table_dat["BACKUPS_SCHEDULE"]
            })};
    }
    else{
        var Tab = {
            tabId: TAB_ID,
            title: "Info",
            icon: 'fa-user',
            tabClass: "subTab",
            parentTab: "dr-top-tab",
            listHeader: "HyperCX Vault Status",
            lockable: false,
            content: HtmlFailureTemplate()
            };  
    }

    return Tab;
});
