define(function(require) {
    var Locale = require('utils/locale');
    var Buttons = require('./vdcs-tab/buttons');
    _html = "<iframe onload='iFrameHeight()' id='blockrandom' name='' src='http://zabbix/grafana/d/Z-rFqENGk/main?orgId=2&refresh=5s&from=1606245065955&to=1606266665955/' width='100%' height='900' scrolling='no' frameborder='0' class='wrapper' style='height: 960px;'No iframes></iframe><script>var iframe = document.getElementById('blockrandom'); iframe.onload = function(){iframe.style.height = iframe.contentWindow.document.body.scrollHeight + 'px';}</script>";
    TAB_ID = 'hypercx-main-tab'
    var Tab = {
        tabId: TAB_ID,
        title: 'Main',
        icon: 'fa-tachometer-alt',
        tabClass: "subTab",
        parentTab: "hypercx-beat-top-tab",
        listHeader: 'HyperCX Beat Main',
        content:_html
    };
    return Tab;
});
