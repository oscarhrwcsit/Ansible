
define(function(require) {

    var Buttons = {
        "dr-backup.refresh" : {
            type: "action",
            layout: "refresh",
            alwaysActive: true
        }
    };
    return Buttons; 
}); 
