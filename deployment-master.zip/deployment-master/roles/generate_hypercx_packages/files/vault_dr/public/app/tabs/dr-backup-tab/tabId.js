define(function(require){

    return "dr-backup-tab";

});