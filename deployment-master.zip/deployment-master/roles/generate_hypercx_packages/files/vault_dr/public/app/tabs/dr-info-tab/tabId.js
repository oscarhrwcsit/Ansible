define(function(require){

    return "dr-info-tab";

});
