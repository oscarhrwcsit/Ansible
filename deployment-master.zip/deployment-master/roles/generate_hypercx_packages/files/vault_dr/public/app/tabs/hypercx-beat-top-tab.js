define(function(require) {
  var Locale = require('utils/locale');
  var TAB_ID = 'hypercx-beat-top-tab';
  var Tab = {
    tabId: TAB_ID,
    title: "HyperCX Beat",
    no_content: true
  }
  return Tab;
});
