
define(function(require) {
    var Sunstone = require('sunstone');
    var DataTable = require('./datatable');
    var OpenNebulaResource = require('opennebula/dr-backup');
    var CommonActions = require('utils/common-actions');

    var TAB_ID = require('./tabId');

    var XML_ROOT = "dr-backup"
    var RESOURCE = "dr-backup"

    var _commonActions = new CommonActions(OpenNebulaResource, RESOURCE, TAB_ID,
        XML_ROOT, "DR created");

    var _actions = {
        "dr-backup.list" : _commonActions.list(),
        "dr-backup.refresh" : _commonActions.refresh()
    };

    return _actions;
}); 
