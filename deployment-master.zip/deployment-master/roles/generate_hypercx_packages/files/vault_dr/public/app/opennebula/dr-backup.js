define(function(require) {

    var opennebula = require("opennebula");
    var RESOURCE = "Dr";
  
    var Dr = {
      "resource": RESOURCE,
      "list" : function(params, RESOURCE) {
        var callback = params.success;
        var _table_dat;
        $.ajax('/hypercx/dr-backup',
                  {            
                      async: false,
                      success: function (data, status, xhr) {
                              return callback? callback('/hypercx/dr-backup', data): null
                      }
                  });
      },
      "getName": function(id){
        return "";
      }
    }
  
    return Dr;
  }) 
