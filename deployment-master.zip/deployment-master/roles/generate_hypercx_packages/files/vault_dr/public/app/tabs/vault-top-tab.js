define(function(require) {
    var Locale = require('utils/locale');
    var TAB_ID = 'vault-top-tab';
  
    var VaultTab = {
      tabId: TAB_ID,
      title: "Vault",
      no_content: true
    }
  
    return VaultTab;
  }); 