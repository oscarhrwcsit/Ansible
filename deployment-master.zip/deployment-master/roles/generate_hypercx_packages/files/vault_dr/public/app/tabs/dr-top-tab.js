define(function(require) {
    var Locale = require('utils/locale');
    var TAB_ID = 'dr-top-tab';
  
    var DrTab = {
      tabId: TAB_ID,
      title: "DR",
      no_content: true
    }
  
    return DrTab;
  }); 