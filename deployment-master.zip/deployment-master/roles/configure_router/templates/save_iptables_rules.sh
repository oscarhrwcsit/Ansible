#!/bin/bash

iptables-save > /etc/iptables/iptables.rules

{% if "router2" in groups %}

if [ "$HOSTNAME" != router1 ]; then
    echo ""
    echo "Copying firewall rules to router 1"
    rsync -avP -e "ssh -o StrictHostKeyChecking=no" /etc/iptables/iptables.rules root@{{groups['router1'][0]}}:/etc/iptables/iptables.rules || echo "Failed while copying firewall rules to router1"
    echo "Reloading rules on router 1"
    ssh -o StrictHostKeyChecking=no root@{{groups['router1'][0]}} 'systemctl restart iptables' || echo "Could not restart iptables on router1"
fi

if [ "$HOSTNAME" != router2 ]; then
    echo ""
    echo "Copying firewall rules to router 2"
    rsync -avP -e "ssh -o StrictHostKeyChecking=no" /etc/iptables/iptables.rules root@{{groups['router2'][0]}}:/etc/iptables/iptables.rules || echo "Failed while copying firewall rules to router2"
    echo "Reloading rules on router 2"
    ssh -o StrictHostKeyChecking=no root@{{groups['router2'][0]}} 'systemctl restart iptables' || echo "Could not restart iptables on router2"
fi
{% endif %}

{% if "router3" in groups %}

if [ "$HOSTNAME" != router3 ]; then
    echo ""
    echo "Copying firewall rules to router 3"
    rsync -avP -e "ssh -o StrictHostKeyChecking=no" /etc/iptables/iptables.rules root@{{groups['router3'][0]}}:/etc/iptables/iptables.rules || echo "Failed while copying firewall rules to router3"
    echo "Reloading rules on router 3"
    ssh -o StrictHostKeyChecking=no root@{{groups['router3'][0]}} 'systemctl restart iptables' || echo "Could not restart iptables on router3"
fi

{% endif %}



