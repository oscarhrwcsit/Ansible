#!/bin/bash
TYPE=$1
NAME=$2
STATE=$3
case $STATE in
        "MASTER") /bin/systemctl start openvpn@server
                  /bin/ip r del default via {{ container_gateway }}
                  ;;
        "BACKUP") /bin/systemctl stop openvpn@server
                  /bin/ip r add default via {{ container_gateway }}
                  ;;
        "STOP") /bin/systemctl stop openvpn@server
                /bin/ip r add default via {{ container_gateway }}
                  ;;
        "FAULT")  /bin/systemctl stop openvpn@server
                  /bin/ip r add default via {{ container_gateway }}
                  exit 0
                  ;;
        *)        /usr/bin/logger "keepalived unknown state"
                  exit 1
                  ;;
esac
