#!/bin/bash

for arg in "$@"
do
    if [ "$arg" == "--help" ] || [ "$arg" == "-h" ]
    then
        echo "Usage: $0 client_name"
        exit 0
    fi
done

# Client Name
client=$1

if [  -f /etc/openvpn/pki/issued/$client.crt ]; then
    /etc/openvpn/easy_rsa/easyrsa --pki-dir=/etc/openvpn/pki --batch revoke $client
    /etc/openvpn/easy_rsa/easyrsa --pki-dir=/etc/openvpn/pki --batch gen-crl
fi

$(systemctl restart openvpn@server)

echo ""
echo "Client $client revoked successfully!!!"
