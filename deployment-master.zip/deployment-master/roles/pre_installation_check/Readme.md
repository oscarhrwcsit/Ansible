# Overview

This role will clear any unwanted configuration before starting the installation, and will verify some settings to try to avoid future errors.

