# Overview

This role will install or upgrade hypercx Vault and DR in clusters, depending if the package was installed or not.

If the package was just installed for the first time, it will disable and stop the service.

If Vaulr/DR were upgraded, the service will maintain the same state. This means that this playbook will not change the state (stopped or started) or enable/disable the service.

