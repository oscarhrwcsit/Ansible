#!/bin/bash

path=/etc/openvpn/pki/issued # path to certificate directory

#users=`ls -F $path | sed 's/I\///g'` # array of certificate name
users=`ls -F $path | sed 's/\///g' | cut -d '.' -f 1`

echo "{"
echo "\"data\":["

comma=""
for user in $users
do
    echo "    $comma{\"{#VPNUSER}\":\"$user\"}"
    comma=","
done

echo "]"
echo "}"
