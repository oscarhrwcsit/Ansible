#!/bin/bash

datastores=`onedatastore list | awk '{print $1}' | grep -v 'ID'`

echo "{"
echo "\"data\":["

comma=""
for ds in $datastores
do
    echo "    $comma{\"{#DATASTORE}\":\"$ds\"}"
    comma=","
done

echo "]"
echo "}"

