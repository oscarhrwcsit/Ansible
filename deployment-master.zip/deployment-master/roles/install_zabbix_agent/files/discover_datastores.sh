#!/bin/bash

datastores=`cat /var/lib/hypercx/datastores/gluster_mount/Datastores-List`

echo "{"
echo "\"data\":["
comma=""
for ds in $datastores
do
    echo "    $comma{\"{#DATASTORE}\":\"$ds\"}"
    comma=","
done
echo "]"
echo "}"


