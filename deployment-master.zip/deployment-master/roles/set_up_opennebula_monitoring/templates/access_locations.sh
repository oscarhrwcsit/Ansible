#!/bin/bash

##--VARIABLES--##
LOG_PATH="/var/log/nginx/access.log"
STATUS_FILE_PATH="/var/lib/one/grafana/location_status"
IP_INI=0.0.0.0
IP_COUNT=0
IP_LAT=""

DB_HOST={{ groups['zabbix'][0] }}
DB_USER=worldmap
DB_PASS={{ database_password }}
DB_NAME=worldmap
DB_TABLE=bento_logins

##--FUNCTIONS--##
save_past_total_lines () {
   PAST_TOTAL_LINES=$CURRENT_TOTAL_LINES
   sed -i "7s/.*/$PAST_TOTAL_LINES/" $STATUS_FILE_PATH
}

calculate_start_line () {
   START_READ_LINE=$(($CURRENT_TOTAL_LINES-$PAST_TOTAL_LINES))
   ((START_READ_LINE++))
}

get_and_save_IP_info () {
   IP_INFO=`curl -sH "Accept: application/json" -H "Content-Type: application/json" http://ip-api.com/json/$PUB_IP | jq '.lat,.lon,.isp'`
   read -r IP_LAT IP_LON IP_ISP <<<$(echo $IP_INFO)
}

insert_db () {
mysql --host=$DB_HOST --user=$DB_USER --password=$DB_PASS $DB_NAME << EOF
INSERT INTO $DB_TABLE (IP, lat, lng, name, value, timestamp) VALUES (INET_ATON("$IP_INI"), "$IP_LAT", "$IP_LON", '$IP_ISP', "$IP_COUNT", now());
EOF
}

#####------START-----#####
#-Policy to select the starting line to proccess in the log file-#
CURRENT_TOTAL_LINES=`wc $LOG_PATH | awk '{print $1}'`

sed -i "6s/.*/$CURRENT_TOTAL_LINES/" $STATUS_FILE_PATH

FIRST_RUN=`sed -n 5p $STATUS_FILE_PATH`

#-Initial_Condition-#
if [[ $FIRST_RUN -eq 0 ]]
  then
    sed -i "5s/.*/1/" $STATUS_FILE_PATH
    save_past_total_lines
    calculate_start_line
  else
    PAST_TOTAL_LINES=`sed -n 7p $STATUS_FILE_PATH`
#-Preventing_log_rotation-#
    if [[ $CURRENT_TOTAL_LINES -gt $PAST_TOTAL_LINES ]]
      then
        sed -i "7s/.*/$CURRENT_TOTAL_LINES/" $STATUS_FILE_PATH
        START_READ_LINE=$PAST_TOTAL_LINES
        ((START_READ_LINE++))
      else
#-If_the_log_remain_with_the_sames_lines-#
        if [[ $CURRENT_TOTAL_LINES -eq $PAST_TOTAL_LINES ]]
          then
            exit 0
          else
            save_past_total_lines
            calculate_start_line
        fi
    fi
fi

###---Log_Proccesing---###
PUB_IP_LIST=`tail -n +$START_READ_LINE $LOG_PATH | grep login.js |awk '{print $1}' | egrep -vE '^10\.|^192\.168\.|^127\.|^172\.1[6-9]\.|^172\.2[0-9]\.|^172\.3[0-1]\.' | sort`

if [[ -z $PUB_IP_LIST ]]
  then
    exit 0
fi

for PUB_IP in $PUB_IP_LIST
 do
    if [[ $PUB_IP = $IP_INI ]]
     then
       ((IP_COUNT++))
     else
       if [[ -z $IP_LAT ]]
        then
          IP_INI=$PUB_IP
          get_and_save_IP_info
          ((IP_COUNT++))
        else
          insert_db
          IP_COUNT=0
          IP_INI=$PUB_IP
          get_and_save_IP_info
          ((IP_COUNT++))
       fi
    fi
done

insert_db
IP_COUNT=0

exit 0
