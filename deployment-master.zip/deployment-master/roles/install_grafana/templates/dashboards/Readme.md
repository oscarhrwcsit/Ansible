# Update any dashboard

Change version field to this:

```
"version": {{ ansible_date_time.epoch }}
```

# Udating Main VIEW

Besides **version** field, do all of this.

## Change links URL to point to zabbix ip for other dashboards

One url is for web-ui and the other one for resources

```
"url": "http://{{ ansible_default_ipv4.address }}/grafana/d/5Dd3nwHGz/web-ui"
"url": "http://{{ ansible_default_ipv4.address }}/grafana/d/bZuqj-NMz/resources"
```

## HDD storage gauge

Change HDD storage gauge with the following code:

```
{% for datastore in system_datastores.stdout_lines %}
    {
      "datasource": null,
      "fieldConfig": {
        "defaults": {
          "custom": {},
          "mappings": [],
          "max": 11995671859036,
          "min": 0,
          "thresholds": {
            "mode": "percentage",
            "steps": [
              {
                "color": "green",
                "value": null
              },
              {
                "color": "#EAB839",
                "value": 70
              },
              {
                "color": "red",
                "value": 90
              }
            ]
          },
          "unit": "bytes"
        },
        "overrides": []
      },
      "gridPos": {
{% if loop.length == 1 %}
        "h": 8,
{% else %}
        "h": 4,
{% endif %}
        "w": 5,
        "x": 0,
{% if loop.index == 1 %}
        "y": 7
{% else %}
        "y": 11
{% endif %}
      },
      "id": {{ loop.index * 123 }},
      "options": {
        "reduceOptions": {
          "calcs": [
            "last"
          ],
          "fields": "",
          "values": false
        },
        "showThresholdLabels": false,
        "showThresholdMarkers": true
      },
      "pluginVersion": "7.1.4",
      "targets": [
        {
          "application": {
            "filter": "Orchestrator"
          },
          "functions": [],
          "group": {
            "filter": "Orchestrators"
          },
          "host": {
            "filter": "orchestrator1"
          },
          "item": {
            "filter": "Used_Space_on_{{ datastore }}"
          },
          "options": {
            "showDisabledItems": false,
            "skipEmptyValues": false
          },
          "proxy": {
            "filter": ""
          },
          "queryType": 0,
          "refId": "A",
          "resultFormat": "time_series",
          "table": {
            "skipEmptyValues": false
          },
          "tags": {
            "filter": ""
          },
          "trigger": {
            "filter": ""
          },
          "triggers": {
            "acknowledged": 2,
            "count": true,
            "minSeverity": 3
          }
        }
      ],
      "timeFrom": null,
      "timeShift": null,
      "title": "{{ datastore }} Datastore",
      "type": "gauge"
    },
{% endfor %}
```








