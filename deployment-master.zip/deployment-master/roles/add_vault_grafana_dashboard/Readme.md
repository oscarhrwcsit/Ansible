This role is extremely simple. Will add a grafana dashboard for HyperCX Vault. 

This role assumes Grafana is already installed and properly working. In other words, HyperCX Cluster must be fully deployed before creating a shared vault.
