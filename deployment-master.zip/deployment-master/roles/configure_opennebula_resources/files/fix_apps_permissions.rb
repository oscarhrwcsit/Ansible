#!/usr/bin/env ruby


##############################################################################
# Environment Configuration
##############################################################################
ONE_LOCATION = ENV['ONE_LOCATION']

if !ONE_LOCATION
    RUBY_LIB_LOCATION = '/usr/lib/one/ruby' if !defined?(RUBY_LIB_LOCATION)
    GEMS_LOCATION     = '/usr/share/one/gems' if !defined?(GEMS_LOCATION)
else
    RUBY_LIB_LOCATION = ONE_LOCATION + '/lib/ruby' if !defined?(RUBY_LIB_LOCATION)
    GEMS_LOCATION     = ONE_LOCATION + '/share/gems' if !defined?(GEMS_LOCATION)
end

if File.directory?(GEMS_LOCATION)
    Gem.use_paths(GEMS_LOCATION)
end

$LOAD_PATH << RUBY_LIB_LOCATION

#$: << RUBY_LIB_LOCATION

##############################################################################
# Required libraries
##############################################################################
require 'opennebula'

include OpenNebula

@client = Client.new


#### Everything here is hardcoded, since this is only a temporary solution for a very specific task
#### This script will scan markets, and get apps for any market with driver == virtalus
#### For each app, if others USE permission is 0, change to 1

def fix_apps_in(market)
  if market['MARKET_MAD'] == "virtalus"
    return unless market['MARKETPLACEAPPS'].key?("ID")
    market['MARKETPLACEAPPS']['ID'].each do |app_id|
      puts "Fixing permissions for marketapp #{app_id}"
      fix_permissions_for(app_id)
    end
  end
end

def fix_permissions_for(app_id)
  app=MarketPlaceApp.new_with_id(app_id, @client)
  app.info
  if app.to_hash['MARKETPLACEAPP'].key?('PERMISSIONS')
    if app.to_hash['MARKETPLACEAPP']['PERMISSIONS']['OTHER_U'] == "0"
      app.chmod_octet("644")
    end
  end
end


markets = MarketPlacePool.new(@client)
markets.info_all

if markets.to_hash['MARKETPLACE_POOL']['MARKETPLACE'].is_a?(Array)
  markets.to_hash['MARKETPLACE_POOL']['MARKETPLACE'].each do |market|
    fix_apps_in(market)
  end
else
  fix_apps_in(markets.to_hash['MARKETPLACE_POOL']['MARKETPLACE'])
end



