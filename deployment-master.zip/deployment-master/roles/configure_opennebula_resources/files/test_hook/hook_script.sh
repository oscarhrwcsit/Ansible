#!/bin/bash
touch /tmp/hooks_working
