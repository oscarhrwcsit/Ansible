#!/bin/bash

for arg in "$@"
do
    if [ "$arg" == "--help" ] || [ "$arg" == "-h" ]
    then
        echo "Usage: $0 client_name"
        exit 0
    fi
done

# Client Name
client=$1

if [ ! -f /etc/openvpn/pki/issued/$client.crt ]; then
    /etc/openvpn/easy_rsa/easyrsa --pki-dir=/etc/openvpn/pki --batch --req-cn=$client gen-req $client nopass
    /etc/openvpn/easy_rsa/easyrsa --pki-dir=/etc/openvpn/pki --batch --req-cn=$client sign-req client $client
fi

client_config=/root/$client.ovpn

cat > $client_config <<EOF
dev tun
cipher AES-256-CBC
user root
group root
persist-key
persist-tun
status openvpn-status.log
verb 3
explicit-exit-notify 1
client
remote 103.88.253.244 1194 udp
EOF

echo "<ca>" >> $client_config
cat /etc/openvpn/pki/ca.crt >> $client_config
echo "</ca>" >> $client_config
echo "<key>" >> $client_config
cat /etc/openvpn/pki/private/$client.key >> $client_config
echo "</key>" >> $client_config
echo "<cert>" >> $client_config
grep -A 90 -P '^-----BEGIN CERTIFICATE-----' /etc/openvpn/pki/issued/$client.crt >> $client_config
echo "</cert>" >> $client_config
echo "key-direction 1" >> $client_config
echo "<tls-auth>" >> $client_config
cat /etc/openvpn/ta.key >> $client_config
echo "</tls-auth>" >> $client_config

echo ""
echo "Client ovpn file generated locally on $client_config"
