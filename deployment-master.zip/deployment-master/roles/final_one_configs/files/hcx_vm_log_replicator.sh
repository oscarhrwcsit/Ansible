#!/bin/bash

hostname=`hostname`
logfolder=/var/log/one/

##--To evaluate if the node is the leader or not--##
leader=`onezone show 0 | grep $hostname | grep leader | wc -l`

if [ $leader -gt 0 ]
  then
     cd $logfolder
     logfiles=`find -regex '.*/[0-9]+\.log' | cut -d '/' -f 2`
     for logfile in $logfiles
       do
         rsync -az $logfile oneadmin@orchestrator1:/var/log/one/
         rsync -az $logfile oneadmin@orchestrator2:/var/log/one/
         rsync -az $logfile oneadmin@orchestrator3:/var/log/one/
       done
fi


