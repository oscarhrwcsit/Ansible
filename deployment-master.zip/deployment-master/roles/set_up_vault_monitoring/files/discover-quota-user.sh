#!/bin/bash

users=`sudo xfs_quota -x -c 'report -u' /var/lib/hypercx/vault/ | awk '{print $1}' | grep -v 'User' | grep -v 'Blocks' | grep -v '-'` # array of quota users

echo "{"
echo "\"data\":["

comma=""
for user in $users
do
    echo "    $comma{\"{#QUOTAUSER}\":\"$user\"}"
    comma=","
done

echo "]"
echo "}"

