#!/bin/bash

projects=`sudo xfs_quota -x -c 'report -p' /var/lib/hypercx/vault/ | awk '{print $1}' | grep -v 'Project' | grep -v 'Blocks' | grep -v '-' | grep -v '#0'` # array of projects (folders)


echo "{"
echo "\"data\":["

comma=""
for project in $projects
do
    echo "    $comma{\"{#QUOTAPROJECT}\":\"$project\"}"
    comma=","
done

echo "]"
echo "}"

